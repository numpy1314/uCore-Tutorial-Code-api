# uCore API 实验原始证据

chapters/chN/reference/ 与 student/ 分别保留参考实现和未填写骨架的原始 result.json、构建/QEMU/GDB 日志。

positive PASS 表示指定现有基础测试通过；negative PASS 表示骨架编译成功并触发本章 TODO。两者不能混为学生作业通过。GDB 冒烟仅证明记录的函数断点可命中，不是全部目标函数动态覆盖。

metadata/manifest.json 保存测试版本、补丁哈希、实际构建提交、Git 树、内核二进制哈希、计数和软件回归结果。metadata/tools/ 保存本次判定工具与测试补丁。regressions/ 是真实 Python 测试输出。historical/ 是未通过的历史记录，不参与最终通过统计。

部分 GDB 日志的工具安装缺少可选 Python 模块，但已执行普通 GDB 命令、断点与记录的页表检查；警告原样保留。

未打包 user/、工具链、内核/文件系统二进制和大体积逐指令调试文件。证据对应运行时的构建哈希，不应以当前目录后来重建的 kernel 替换。
