set pagination off
set confirm off
set tcp auto-retry on
set tcp connect-timeout 10
set architecture riscv:rv64
target remote 127.0.0.1:60359
break scheduler
continue
disable breakpoints
set $pt = (pagetable_t)uvmcreate()
if $pt == 0
 echo allocation failed\n
 quit 1
end
set $frame = (unsigned long)kalloc()
if $frame == 0
 echo allocation failed\n
 quit 1
end
set $mapped = mappages($pt, 0x4000, 4096, $frame, 0x16)
printf "MAP_FIRST=%d\n", $mapped
set $entry = (pte_t *)walk($pt, 0x4000, 0)
p/x *$entry
set $pa = (unsigned long)walkaddr($pt, 0x4123)
printf "PAGE_BASE=%d\n", $pa == $frame
set $byte = (unsigned long)useraddr($pt, 0x4123)
printf "BYTE_OFFSET=%d\n", $byte == $frame + 0x123
call uvmunmap($pt, 0x4000, 1, 0)
printf "UNMAP_KEEP_CLEARED=%d\n", *$entry == 0
set $pa = (unsigned long)walkaddr($pt, 0x4000)
printf "UNMAP_KEEP_ABSENT=%d\n", $pa == 0
set $mapped = mappages($pt, 0x4000, 4096, $frame, 0x16)
printf "MAP_AGAIN=%d\n", $mapped
call uvmunmap($pt, 0x4000, 1, 1)
printf "UNMAP_FREE_CLEARED=%d\n", *$entry == 0
set $pa = (unsigned long)walkaddr($pt, 0x4000)
printf "UNMAP_FREE_ABSENT=%d\n", $pa == 0
call uvmunmap($pt, 0x3ffffff000, 1, 0)
call freewalk($pt)
printf "PAGE_TABLE_GDB_COMPLETE\n"
detach
quit
